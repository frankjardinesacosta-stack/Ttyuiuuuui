# SENSI OG — cambios de interfaz

- La aplicación abre directamente la pantalla existente para introducir la key; se retiró la vista de calculadora y su secuencia de acceso.
- La pantalla de key utiliza `GhostPatchesBackground`, el mismo recurso visual que usa el menú de patches.
- Al pulsar «Entrar» se reproduce `welcome_baby.m4a`, el mismo audio que se reproduce al cerrar sesión.
- Se actualizó el nombre visible de la app y las etiquetas principales del menú a «SENSI OG».

## Alcance

Estos cambios son de interfaz. No se creó ni se conectó un servicio/API de licencias nuevo y no se modificó el proveedor de keys existente, la validación de licencias ni el comportamiento del motor de patches. La compilación de iOS debe ejecutarse en GitHub Actions/macOS con Xcode.
